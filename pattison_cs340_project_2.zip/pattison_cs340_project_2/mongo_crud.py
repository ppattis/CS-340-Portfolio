from pymongo import MongoClient
from bson.objectid import ObjectId


class mongo_crud(object):

    #
    #  Class constructor...
    def __init__(self, hostname="localhost", port=27017, username=None, password=None, database=None):
        
        #  Initialize a MongoDB client
        if ((username != None) and (password != None)):
            if database != None:
                url = "mongodb://%s:%s@%s:%s/?authSource=%s&authMechanism=SCRAM-SHA-256" % (username, password, hostname, port, database)
            else:
                url = "mongodb://%s:%s@%s:%s/?authSource=admin&authMechanism=SCRAM-SHA-256" % (username, password, hostname, port)
        else:
            url = "mongodb://%s:%s" % (hostname, port)
        self.client = MongoClient(url)
        self.db = None
        if database != None:
            self.database = database
            self.db = self.client[database]
        self.collection = None

    #
    #  function to use a specific database
    def set_database(self, database):
        self.database = database
        self.db = self.client[database]
    
    #
    #  function to use a specific collection in selected DB...
    def use(self, collection):
        self.collection = collection

    #
    #  helper function to verify that search term is an instance of a dictionary...
    def is_search_valid(self, search):

        if not isinstance(search, dict):
            raise Exception('Search term must be a dictionary!')

    #
    #  helper function to verify that instance of mongo_crud is ready to be used.
    #  basically that a DB and collection are selected.
    def is_db_ready(self):

        if ( (self.db == None) or (self.collection == None) ):
            raise Exception('No database or collection selected')

    #
    #  function to create documents in the database/collection selected...
    def create(self, data):
        
        self.is_db_ready()

        if isinstance(data, list):
        
            self.db[self.collection].insert_many(data)

        elif isinstance(data, dict):

            self.db[self.collection].insert(data)

        else:

            raise Exception("Data must be a dictionary, or List of dictionaries!")

    #
    #  function to read documents from the database/collection selected...
    def read(self, search = None, many = True):

        self.is_db_ready()

        if search != None:

            self.is_search_valid(search)

            if not many:

                if self.db[self.collection].count_documents(search) > 0:

                    return self.db[self.collection].find_one(search)

                else:

                    raise Exception('No data found to match query!')
            
            else:

                if self.db[self.collection].count_documents(search) > 0:

                    return self.db[self.collection].find(search, {'_id': False})
                else:

                    raise Exception('No data found to match query!')

        return list(self.db[self.collection].find_one())

    #
    #  function to update documents in the database/collection selected...
    def update(self, search, data, many = False, upsert = True):

        self.is_search_valid(search)

        self.is_db_ready()

        ret_value = None

        if not many:

            ret_value = self.db[self.collection].update_one(search, data, upsert)

        else:

            ret_value = self.db[self.collection].update_many(search, data, upsert)

        return ret_value

    #
    #  function to delete documents in the database/collection selected...
    def delete(self, search, many = False):  

        self.is_search_valid(search)

        self.is_db_ready()      

        ret_value = None
        
        if not many:

            ret_value = self.db[self.collection].delete_one(search)

        else:

            ret_value = self.db[self.collection].delete_many(search)

        return ret_value


            

